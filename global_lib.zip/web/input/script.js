let formInputs = {};
let inputAnimToken = 0;
let isClosingInput = false;
let isOpeningInput = false;
let closeInputFallback = null;
let openInputTimeout = null;

const s_click = new Audio('./sounds/click.mp3');
const s_swipe = new Audio('./sounds/swipe.mp3');
s_click.volume = 0.5;
s_swipe.volume = 0.5;

const playUiSound = (audio) => {
    try {
        audio.currentTime = 0;
        audio.play();
    } catch (e) { /* ignore */ }
};

const clearInputAnimTimers = () => {
    if (closeInputFallback) {
        clearTimeout(closeInputFallback);
        closeInputFallback = null;
    }
    if (openInputTimeout) {
        clearTimeout(openInputTimeout);
        openInputTimeout = null;
    }
    $('#input-panel').off('animationend.inputClose animationend.inputOpen');
};

const hardResetInputVisual = () => {
    clearInputAnimTimers();
    isClosingInput = false;
    isOpeningInput = false;
    const $panel = $('#input-panel');
    $panel.removeClass('panel-open panel-close is-visible');
    $panel.css('animation', 'none');
    if ($panel[0]) void $panel[0].offsetWidth;
    $panel.css('animation', '');
};

const openInputPanel = () => {
    const $root = $('#input-root');
    const $panel = $('#input-panel');
    inputAnimToken += 1;
    const token = inputAnimToken;
    hardResetInputVisual();

    $root.addClass('is-open');
    isOpeningInput = true;

    requestAnimationFrame(() => {
        if (token !== inputAnimToken) return;
        void $panel[0].offsetHeight;
        requestAnimationFrame(() => {
            if (token !== inputAnimToken) return;
            $panel.addClass('is-visible panel-open');
        });
    });

    openInputTimeout = setTimeout(() => {
        if (token !== inputAnimToken) return;
        isOpeningInput = false;
        openInputTimeout = null;
    }, 620);
};

const closeInputPanel = (onDone) => {
    const $root = $('#input-root');
    const $panel = $('#input-panel');

    const finish = (token) => {
        if (token !== undefined && token !== inputAnimToken) return;
        clearInputAnimTimers();
        isClosingInput = false;
        isOpeningInput = false;
        $root.removeClass('is-open');
        $panel.removeClass('panel-open panel-close is-visible');
        $panel.css('animation', '');
        $panel.empty();
        formInputs = {};
        if (typeof onDone === 'function') onDone();
    };

    const visible = $panel.hasClass('is-visible') || $panel.hasClass('panel-open');
    if (!visible) {
        finish();
        return;
    }

    if (isClosingInput) return;

    inputAnimToken += 1;
    const token = inputAnimToken;
    clearInputAnimTimers();
    isOpeningInput = false;
    isClosingInput = true;

    $panel.removeClass('panel-open');
    $panel.css('animation', 'none');
    void $panel[0].offsetWidth;
    $panel.css('animation', '');
    $panel.addClass('is-visible panel-close');

    closeInputFallback = setTimeout(() => finish(token), 520);
    $panel.off('animationend.inputClose').one('animationend.inputClose', function (e) {
        if (e.target !== $panel[0]) return;
        if (token !== inputAnimToken) return;
        clearTimeout(closeInputFallback);
        closeInputFallback = null;
        finish(token);
    });
};

const OpenMenu = (data) => {
    if (data == null || data == '') return null;

    playUiSound(s_swipe);
    formInputs = {};

    const headerText = data.header != null ? data.header : 'Form Title';
    const headerIcon = data.headerIcon || 'mdi:form-textbox';
    const submitText = data.submitText ? data.submitText : 'Confirmar';

    let form = [
        "<form id='qb-input-form' class='input-dialog-form'>",
        "<div class='input-dialog-card'>",
        "<div class='input-dialog-banner'>",
        `<span class='input-dialog-banner-text'>${headerText}</span>`,
        `<span class='iconify input-dialog-banner-icon' data-icon='${headerIcon}' data-width='32' data-height='32'></span>`,
        '</div>',
        "<div class='input-dialog-body'>"
    ];

    data.inputs.forEach((item) => {
        switch (item.type) {
            case 'text':
                form.push(renderTextInput(item));
                break;
            case 'password':
                form.push(renderPasswordInput(item));
                break;
            case 'number':
                form.push(renderNumberInput(item));
                break;
            case 'radio':
                form.push(renderRadioInput(item));
                break;
            case 'select':
                form.push(renderSelectInput(item));
                break;
            case 'checkbox':
                form.push(renderCheckboxInput(item));
                break;
            case 'color':
                form.push(renderColorInput(item));
                break;
            default:
                form.push(`<div class="input-dialog-field"><div class="input-dialog-label">${item.text || ''}</div></div>`);
        }
    });

    form.push(
        '</div>',
        "<div class='input-dialog-actions'>",
        "<button type='button' class='input-dialog-btn cancel-btn' id='qb-input-cancel'>",
        "<span>Cancelar</span>",
        '</button>',
        `<button type='submit' class='input-dialog-btn submit-btn' id='qb-input-submit'>`,
        `<span>${submitText}</span>`,
        '</button>',
        '</div>',
        '</div>',
        '</form>'
    );

    $('#input-panel').html(form.join(''));

    if (typeof Iconify !== 'undefined' && Iconify.scan) {
        Iconify.scan(document.querySelector('#input-panel'));
    }

    openInputPanel();

    $('#qb-input-form').on('change', function (event) {
        if ($(event.target).attr('type') == 'checkbox') {
            const value = $(event.target).is(':checked') ? 'true' : 'false';
            formInputs[$(event.target).attr('value')] = value;
        } else {
            formInputs[$(event.target).attr('name')] = $(event.target).val();
        }
    });

    $('#qb-input-cancel').on('click', function () {
        playUiSound(s_click);
        CancelMenu();
    });

    $('#qb-input-form').on('submit', async function (event) {
        if (event != null) event.preventDefault();
        if (isClosingInput) return;
        playUiSound(s_click);
        await $.post(`https://${GetParentResourceName()}/inputSubmit`, JSON.stringify({ data: formInputs }));
        CloseMenu();
    });
};

const renderInputField = (label, description, inputHtml) => {
    const descHtml = description ? `<div class="input-dialog-description">${description}</div>` : '';
    const labelHtml = label ? `<label class="input-dialog-label">${label}</label>` : '';
    return `<div class="input-dialog-field">${labelHtml}${descHtml}${inputHtml}</div>`;
};

const getVisibleLabel = (item) =>
    item.label != null && item.label !== ''
        ? item.label
        : item.text != null && item.text !== ''
          ? item.text
          : '';

const renderTextInput = (item) => {
    const { text, name } = item;
    formInputs[name] = item.default ? item.default : '';
    const isRequired = item.isRequired == 'true' || item.isRequired ? 'required' : '';
    const defaultValue = item.default ? `value="${item.default}"` : '';
    const inputHtml = `<input placeholder="${text || ''}" type="text" class="input-dialog-input form-control" name="${name}" ${defaultValue} ${isRequired}/>`;
    return renderInputField(getVisibleLabel(item), null, inputHtml);
};

const renderPasswordInput = (item) => {
    const { text, name } = item;
    formInputs[name] = item.default ? item.default : '';
    const isRequired = item.isRequired == 'true' || item.isRequired ? 'required' : '';
    const defaultValue = item.default ? `value="${item.default}"` : '';
    const inputHtml = `<input placeholder="${text || ''}" type="password" class="input-dialog-input form-control" name="${name}" ${defaultValue} ${isRequired}/>`;
    return renderInputField(getVisibleLabel(item), null, inputHtml);
};

const renderNumberInput = (item) => {
    try {
        const { text, name } = item;
        formInputs[name] = item.default ? item.default : '';
        const isRequired = item.isRequired == 'true' || item.isRequired ? 'required' : '';
        const defaultValue = item.default ? `value="${item.default}"` : '';
        const inputHtml = `<input placeholder="${text || ''}" type="number" class="input-dialog-input form-control" name="${name}" ${defaultValue} ${isRequired}/>`;
        return renderInputField(getVisibleLabel(item), null, inputHtml);
    } catch (err) {
        return '';
    }
};

const renderRadioInput = (item) => {
    const { options, name, text } = item;
    formInputs[name] = options[0].value;
    const title = item.label != null ? item.label : text;
    let div = `<div class="input-dialog-field"><div class="input-dialog-label">${title}</div><div class="input-group">`;
    options.forEach((option, index) => {
        div += `<label for="radio_${name}_${index}"> <input type="radio" id="radio_${name}_${index}" name="${name}" value="${option.value}"
                ${item.default ? (item.default == option.value ? 'checked' : '') : index == 0 ? 'checked' : ''}> ${option.text}</label>`;
    });
    div += '</div></div>';
    return div;
};

const renderCheckboxInput = (item) => {
    const { options, name, text } = item;
    const title = item.label != null ? item.label : text;
    let div = `<div class="input-dialog-field"><div class="input-dialog-label">${title}</div><div class="input-group-chk">`;
    options.forEach((option, index) => {
        div += `<label for="chk_${name}_${index}">${option.text} <input type="checkbox" id="chk_${name}_${index}" name="${name}" value="${option.value}" ${option.checked ? 'checked' : ''}></label>`;
        formInputs[option.value] = option.checked ? 'true' : 'false';
    });
    div += '</div></div>';
    return div;
};

const renderSelectInput = (item) => {
    const { options, name, text } = item;
    let div = `<div class="input-dialog-field"><label class="input-dialog-label">${getVisibleLabel(item)}</label>`;
    if (text && text !== getVisibleLabel(item)) div += `<div class="input-dialog-description">${text}</div>`;
    div += `<select class="input-dialog-input form-select" name="${name}" title="${text || ''}">`;
    formInputs[name] = options[0].value;

    options.forEach((option) => {
        const isDefaultValue = item.default == option.value;
        div += `<option value="${option.value}" ${isDefaultValue ? 'selected' : ''}>${option.text}</option>`;
        if (isDefaultValue) formInputs[name] = option.value;
    });
    div += '</select></div>';
    return div;
};

const renderColorInput = (item) => {
    const { text, name } = item;
    formInputs[name] = item.default ? item.default : '#ffffff';
    const isRequired = item.isRequired == 'true' || item.isRequired ? 'required' : '';
    const defaultValue = item.default ? `value="${item.default}"` : '';
    const inputHtml = `<input type="color" class="input-dialog-input form-control" name="${name}" ${defaultValue} ${isRequired}/>`;
    return renderInputField(getVisibleLabel(item), text !== getVisibleLabel(item) ? text : null, inputHtml);
};

const CloseMenu = () => {
    if (isClosingInput) return;
    playUiSound(s_swipe);
    closeInputPanel();
};

const SetStyle = (style) => {
    var stylesheet = $('<link>', {
        rel: 'stylesheet',
        type: 'text/css',
        href: `./input/styles/${style}.css?v=2`
    });
    stylesheet.appendTo('head');
};

const CancelMenu = () => {
    if (!$('#input-root').hasClass('is-open')) return;
    $.post(`https://${GetParentResourceName()}/inputClosed`);
    return CloseMenu();
};

window.addEventListener('message', (event) => {
    const data = event.data;
    const info = data.data;
    const action = data.action;
    switch (action) {
        case 'input:style':
            return SetStyle(info);
        case 'input:open':
            return OpenMenu(info);
        case 'input:close':
            return CloseMenu();
        default:
            return;
    }
});

function SubmitData() {
    const form = document.getElementById('qb-input-form');
    if (form && $('#input-panel').hasClass('is-visible') && !isClosingInput) {
        form.requestSubmit();
    }
}

document.addEventListener('keyup', function (event) {
    if (!$('#input-root').hasClass('is-open')) return;
    const charCode = event.key;
    if (charCode == 'Escape') {
        CancelMenu();
    } else if (charCode == 'Enter') {
        SubmitData();
    }
});

$(document).on('click', '#input-root', function (event) {
    if (event.target.id !== 'input-root') return;
    if (!$('#input-panel').hasClass('is-visible') || isClosingInput || isOpeningInput) return;
    CancelMenu();
});
