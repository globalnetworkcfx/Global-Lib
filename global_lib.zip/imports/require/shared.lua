local loaded = {}

function lib.load(module)
    if type(module) ~= 'string' then return end

    local file = module:gsub('%.', '/') .. '.lua'
    local data = LoadResourceFile(cache.resource, file)
    if not data then return end

    local fn, err = load(data, ('@@%s/%s'):format(cache.resource, file))
    if not fn then
        error(err, 2)
    end

    return fn()
end

function lib.require(modName)
    if loaded[modName] ~= nil then
        return loaded[modName]
    end

    local resource = cache.resource
    local path = modName

    local external = modName:match('^@(.-)/(.+)$')
    if external then
        resource, path = modName:match('^@(.-)/(.+)$')
    end

    path = path:gsub('%.', '/')
    local data = LoadResourceFile(resource, path .. '.lua') or LoadResourceFile(resource, path .. '/init.lua')

    if not data then
        error(("module '%s' not found"):format(modName), 2)
    end

    local fn, err = load(data, ('@@%s/%s'):format(resource, path), 't', _ENV)
    if not fn then error(err, 2) end

    local result = fn()
    if result == nil then result = true end
    loaded[modName] = result
    return result
end

return lib.require
