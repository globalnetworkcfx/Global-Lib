local function pool(poolName)
    return GetGamePool(poolName)
end

function lib.getClosestVehicle(coords, maxDistance, includePlayerVehicle)
    coords = coords or GetEntityCoords(cache.ped or PlayerPedId())
    maxDistance = maxDistance or 5.0
    local playerVehicle = GetVehiclePedIsIn(cache.ped or PlayerPedId(), false)
    local closest, closestDistance

    for _, vehicle in ipairs(pool('CVehicle')) do
        if includePlayerVehicle or vehicle ~= playerVehicle then
            local distance = #(coords - GetEntityCoords(vehicle))
            if distance <= maxDistance and (not closestDistance or distance < closestDistance) then
                closest = vehicle
                closestDistance = distance
            end
        end
    end

    return closest, closestDistance
end

function lib.getNearbyPlayers(coords, maxDistance, includePlayer)
    coords = coords or GetEntityCoords(cache.ped or PlayerPedId())
    maxDistance = maxDistance or 5.0
    local players = {}
    local myId = PlayerId()

    for _, player in ipairs(GetActivePlayers()) do
        if includePlayer or player ~= myId then
            local ped = GetPlayerPed(player)
            local distance = #(coords - GetEntityCoords(ped))
            if distance <= maxDistance then
                players[#players + 1] = {
                    id = player,
                    ped = ped,
                    coords = GetEntityCoords(ped),
                    distance = distance,
                }
            end
        end
    end

    return players
end

function lib.getClosestPlayer(coords, maxDistance, includePlayer)
    local nearby = lib.getNearbyPlayers(coords, maxDistance, includePlayer)
    local closest, closestDistance
    for i = 1, #nearby do
        if not closestDistance or nearby[i].distance < closestDistance then
            closest = nearby[i]
            closestDistance = nearby[i].distance
        end
    end
    if not closest then return end
    return closest.id, closest.ped, closest.coords
end

return lib.getClosestVehicle
