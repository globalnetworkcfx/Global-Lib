local pending = nil
local allowCancel = true

local function closeInput()
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'input:close' })
end

local function resolveInput(result)
    local current = pending
    pending = nil
    allowCancel = true
    if current then
        current:resolve(result)
    end
end

local function ShowInput(data)
    if type(data) ~= 'table' then return end

    if pending then
        resolveInput(nil)
        Wait(0)
    end

    TriggerEvent('global_lib:internal:closeMenu')

    pending = promise.new()
    allowCancel = data.allowCancel ~= false

    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'input:open',
        data = data,
    })

    return Citizen.Await(pending)
end

RegisterNUICallback('inputSubmit', function(data, cb)
    cb('ok')
    closeInput()
    resolveInput(data and data.data or nil)
end)

RegisterNUICallback('inputClosed', function(_, cb)
    cb('ok')
    if not allowCancel then return end
    closeInput()
    resolveInput(nil)
end)

AddEventHandler('global_lib:internal:closeInput', function()
    if not pending then return end
    closeInput()
    resolveInput(nil)
end)

local function iconName(icon)
    if type(icon) == 'table' then icon = icon[1] end
    if type(icon) ~= 'string' or icon == '' then return 'mdi:form-textbox' end
    if icon:find(':') or icon:find('fa%-') or icon:find('fas ') or icon:find('far ') then
        return icon
    end
    return 'fa-solid fa-' .. icon
end

local function mapOptions(options)
    local mapped = {}
    for i = 1, #(options or {}) do
        local opt = options[i]
        mapped[i] = {
            value = tostring(opt.value),
            text = opt.label or opt.text or tostring(opt.value),
            checked = opt.checked or opt.default,
        }
    end
    return mapped
end

local function inputDialog(heading, rows, options)
    if type(rows) ~= 'table' then return end

    local inputs = {}
    local names = {}
    local types = {}

    for i = 1, #rows do
        local row = rows[i]
        if type(row) == 'string' then
            row = { type = 'input', label = row }
        end

        local name = ('field_%s'):format(i)
        local oxType = row.type or 'input'
        names[i] = name
        types[i] = oxType

        local inputType = 'text'
        if row.password then
            inputType = 'password'
        elseif oxType == 'number' or oxType == 'slider' then
            inputType = 'number'
        elseif oxType == 'select' then
            inputType = 'select'
        elseif oxType == 'radio' then
            inputType = 'radio'
        elseif oxType == 'checkbox' or oxType == 'multi-select' then
            inputType = 'checkbox'
        elseif oxType == 'color' then
            inputType = 'color'
        end

        local entry = {
            type = inputType,
            name = name,
            text = row.placeholder or row.description or row.label or '',
            label = row.label or row.text or '',
            default = row.default,
            isRequired = row.required,
        }

        if inputType == 'select' or inputType == 'radio' then
            entry.options = mapOptions(row.options)
            if #entry.options == 0 then
                entry.options[1] = { value = '', text = '-' }
            end
        elseif inputType == 'checkbox' then
            if oxType == 'checkbox' and not row.options then
                entry.options = {
                    { value = name, text = row.label or row.text or '', checked = row.checked or row.default },
                }
            else
                entry.options = mapOptions(row.options)
            end
        end

        inputs[i] = entry
    end

    local result = ShowInput({
        header = heading,
        headerIcon = iconName(options and options.icon),
        submitText = 'Confirmar',
        allowCancel = not options or options.allowCancel ~= false,
        inputs = inputs,
    })

    if not result then return nil end

    local out = {}
    for i = 1, #names do
        local oxType = types[i]
        local name = names[i]
        local row = rows[i]
        local value = result[name]

        if oxType == 'select' or oxType == 'radio' then
            local source = type(row) == 'table' and row.options or {}
            for n = 1, #source do
                if tostring(source[n].value) == tostring(value) then
                    value = source[n].value
                    break
                end
            end
        elseif type(row) == 'table' and oxType == 'checkbox' and not row.options then
            value = value == true or value == 'true'
        elseif oxType == 'number' or oxType == 'slider' then
            value = tonumber(value)
        elseif oxType == 'multi-select' then
            local selected = {}
            local source = type(row) == 'table' and row.options or {}
            for n = 1, #source do
                local key = tostring(source[n].value)
                if result[key] == true or result[key] == 'true' then
                    selected[#selected + 1] = source[n].value
                end
            end
            value = selected
        end

        out[i] = value
    end

    return out
end

local function closeInputDialog()
    if not pending then return end
    closeInput()
    resolveInput(nil)
end

exports('ShowInput', ShowInput)
exports('inputDialog', inputDialog)
exports('closeInputDialog', closeInputDialog)

CreateThread(function()
    Wait(500)
    SendNUIMessage({
        action = 'input:style',
        data = 'default',
    })
end)
