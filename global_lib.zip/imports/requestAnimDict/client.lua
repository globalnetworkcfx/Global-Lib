function lib.requestAnimDict(dict, timeout)
    if not dict then return end
    if HasAnimDictLoaded(dict) then return dict end
    RequestAnimDict(dict)
    local started = GetGameTimer()
    timeout = timeout or 5000
    while not HasAnimDictLoaded(dict) do
        if GetGameTimer() - started > timeout then
            return error(('failed to load anim dict %s'):format(dict), 2)
        end
        Wait(0)
    end
    return dict
end

return lib.requestAnimDict
