lib.array = {}

function lib.array.new(_, ...)
    return { ... }
end

return lib.array
