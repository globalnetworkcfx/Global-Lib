lib.table = table

function table.merge(target, source)
    if type(source) ~= 'table' then return target end
    for k, v in pairs(source) do
        if type(v) == 'table' and type(target[k]) == 'table' then
            table.merge(target[k], v)
        else
            target[k] = v
        end
    end
    return target
end

return lib.table
