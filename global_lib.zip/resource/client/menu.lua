local QBCore

CreateThread(function()
    if GetResourceState('qb-core') ~= 'started' then return end
    local ok, obj = pcall(function()
        return exports['qb-core']:GetCoreObject()
    end)
    if ok then QBCore = obj end
end)

local headerShown = false
local sendData = nil
local contextMenus = {}
local registeredMenus = {}
local openKind = nil
local openContextId = nil
local openListId = nil

local function cloneTable(tbl)
    local copy = {}
    for k, v in pairs(tbl) do
        if type(v) == 'table' then
            local item = {}
            for ik, iv in pairs(v) do
                item[ik] = iv
            end
            copy[k] = item
        else
            copy[k] = v
        end
    end
    return copy
end

local function sortData(data, skipfirst)
    local header = data[1]
    local tempData = data
    if skipfirst then table.remove(tempData, 1) end
    table.sort(tempData, function(a, b)
        return (a.header or '') < (b.header or '')
    end)
    if skipfirst then table.insert(tempData, 1, header) end
    return tempData
end

local function resolveMenuOptions(data, sort, skipFirst, menuOptions)
    if type(menuOptions) == 'table' then return menuOptions end
    if type(sort) == 'table' and sort.title then return sort end
    if type(data) == 'table' and data.title and not data[1] and not data.header then return data end
    return nil
end

local function hud(open)
    if GetResourceState('global_hud') ~= 'started' then return end
    TriggerEvent('global_hud:setInterfaceOpen', 'global_menu', open)
end

local function clearOpenState()
    openKind = nil
    openContextId = nil
    openListId = nil
end

local function closeMenu()
    sendData = nil
    headerShown = false
    clearOpenState()
    SetNuiFocus(false, false)
    hud(false)
    SendNUIMessage({ action = 'menu:close' })
end

local function openMenu(data, sort, skipFirst, menuOptions)
    if type(data) ~= 'table' or not next(data) then return end

    TriggerEvent('global_lib:internal:closeInput')

    local options = resolveMenuOptions(data, sort, skipFirst, menuOptions)
    local actualSort = type(sort) == 'boolean' and sort or false
    local actualSkipFirst = type(skipFirst) == 'boolean' and skipFirst or false

    if actualSort then data = sortData(data, actualSkipFirst) end

    local items = QBCore and QBCore.Shared and QBCore.Shared.Items
    for _, v in pairs(data) do
        if type(v) == 'table' and v.icon and items then
            local item = items[tostring(v.icon)]
            if item and item.image and not string.find(item.image, '//', 1, true) and not string.find(tostring(v.icon), '//', 1, true) then
                v.icon = 'nui://qb-inventory/html/images/' .. item.image
            end
        end
    end

    hud(true)
    SetNuiFocus(true, true)
    headerShown = false
    sendData = data
    SendNUIMessage({
        action = 'menu:open',
        data = cloneTable(data),
        title = options and options.title or nil,
        titleIcon = options and (options.titleIcon or options.icon) or nil,
        subTitle = options and (options.subTitle or options.txt or options.text) or nil,
    })
end

local function showHeader(data, menuOptions)
    if not data or not next(data) then return end
    local options = type(menuOptions) == 'table' and menuOptions or nil
    headerShown = true
    sendData = data
    SendNUIMessage({
        action = 'menu:header',
        data = cloneTable(data),
        title = options and options.title or nil,
        titleIcon = options and (options.titleIcon or options.icon) or nil,
        subTitle = options and (options.subTitle or options.txt or options.text) or nil,
    })
end

local function normalizeIcon(icon)
    if type(icon) == 'table' then icon = icon[1] end
    if type(icon) ~= 'string' or icon == '' then return nil end
    if icon:find('fa%-') or icon:find(':') or icon:find('/') or icon:find('fas ') or icon:find('far ') or icon:find('fab ') then
        return icon
    end
    return 'fa-solid fa-' .. icon
end

local function normalizeOptions(options)
    local list = {}
    if type(options) ~= 'table' then return list end
    if options[1] then
        for i = 1, #options do
            list[i] = options[i]
        end
        return list
    end
    for key, value in pairs(options) do
        if type(value) == 'table' then
            value.title = value.title or key
            list[#list + 1] = value
        end
    end
    return list
end

local function registerContext(context)
    for k, v in pairs(context) do
        if type(k) == 'number' then
            contextMenus[v.id] = v
        else
            contextMenus[context.id] = context
            break
        end
    end
end

local function showContext(id)
    local menu = contextMenus[id]
    if not menu then error('No context menu of such id found.') end

    local items = {}
    if menu.menu then
        items[#items + 1] = {
            header = 'Volver',
            icon = 'fa-solid fa-arrow-left',
            action = function()
                if menu.onBack then menu.onBack() end
                showContext(menu.menu)
            end,
        }
    end

    local options = normalizeOptions(menu.options)
    for i = 1, #options do
        local opt = options[i]
        local disabled = opt.disabled or opt.readOnly
        items[#items + 1] = {
            header = opt.header or opt.title or opt.label or 'Opción',
            txt = opt.txt or opt.text or opt.description,
            icon = normalizeIcon(opt.icon),
            disabled = disabled,
            action = function()
                if disabled then return end
                if opt.onSelect then opt.onSelect(opt.args) end
                if opt.event then TriggerEvent(opt.event, opt.args) end
                if opt.serverEvent then TriggerServerEvent(opt.serverEvent, opt.args) end
                if opt.menu then showContext(opt.menu) end
            end,
        }
    end

    openKind = 'context'
    openContextId = id
    openListId = nil
    openMenu(items, false, false, {
        title = menu.title,
        titleIcon = normalizeIcon(menu.icon),
    })
end

local function hideContext(onExit)
    local id = openContextId
    local menu = id and contextMenus[id]
    closeMenu()
    if onExit and menu and menu.onExit then menu.onExit() end
end

local function registerMenu(data, cb)
    if not data.id then error('No menu id was provided.') end
    if not data.title then error('No menu title was provided.') end
    if not data.options then error('No menu options were provided.') end
    data.cb = cb
    registeredMenus[data.id] = data
end

local function showMenu(id)
    local menu = registeredMenus[id]
    if not menu then error(('No menu with id %s was found'):format(id)) end
    if not menu.options[1] then error(("Can't open empty menu with id %s"):format(id)) end

    local items = {}
    for i = 1, #menu.options do
        local opt = menu.options[i]
        items[i] = {
            header = opt.label or opt.title or opt.header or ('Opción %s'):format(i),
            txt = opt.description or opt.txt,
            icon = normalizeIcon(opt.icon),
            disabled = opt.disabled,
            action = function()
                if menu.cb then
                    menu.cb(i, opt.defaultIndex, opt.args, opt.checked)
                end
            end,
        }
    end

    openKind = 'list'
    openListId = id
    openContextId = nil
    openMenu(items, false, false, { title = menu.title })
end

local function hideMenu(onExit)
    local id = openListId
    local menu = id and registeredMenus[id]
    closeMenu()
    if onExit and menu and menu.onClose then menu.onClose() end
end

local function setMenuOptions(id, options, index)
    if not registeredMenus[id] then error(('No menu with id %s was found'):format(id)) end
    if index then
        registeredMenus[id].options[index] = options
    else
        registeredMenus[id].options = options
    end
end

RegisterNetEvent('global_menu:client:openMenu', function(data, sort, skipFirst, menuOptions)
    openKind = 'qb'
    openMenu(data, sort, skipFirst, menuOptions)
end)

RegisterNetEvent('global_menu:client:closeMenu', function()
    closeMenu()
end)

RegisterNetEvent('qb-menu:client:openMenu', function(data, sort, skipFirst, menuOptions)
    openKind = 'qb'
    openMenu(data, sort, skipFirst, menuOptions)
end)

RegisterNetEvent('qb-menu:client:closeMenu', function()
    closeMenu()
end)

AddEventHandler('global_lib:internal:closeMenu', function()
    if not sendData and not headerShown then return end
    closeMenu()
end)

RegisterNUICallback('menuClicked', function(option, cb)
    if headerShown then headerShown = false end
    PlaySoundFrontend(-1, 'Highlight_Cancel', 'DLC_HEIST_PLANNING_BOARD_SOUNDS', 1)
    SetNuiFocus(false, false)
    hud(false)
    clearOpenState()

    if sendData then
        local data = sendData[tonumber(option)]
        sendData = nil
        if data then
            if data.action ~= nil then
                data.action()
            elseif data.params and data.params.event then
                if data.params.isServer then
                    TriggerServerEvent(data.params.event, data.params.args)
                elseif data.params.isCommand then
                    ExecuteCommand(data.params.event)
                elseif data.params.isQBCommand then
                    TriggerServerEvent('QBCore:CallCommand', data.params.event, data.params.args)
                elseif data.params.isAction then
                    data.params.event(data.params.args)
                else
                    TriggerEvent(data.params.event, data.params.args)
                end
            end
        end
    end

    cb('ok')
end)

RegisterNUICallback('menuClosed', function(_, cb)
    local kind = openKind
    local ctx = openContextId
    local list = openListId
    headerShown = false
    sendData = nil
    clearOpenState()
    SetNuiFocus(false, false)
    hud(false)
    cb('ok')

    if kind == 'context' and ctx and contextMenus[ctx] and contextMenus[ctx].onExit then
        contextMenus[ctx].onExit()
    elseif kind == 'list' and list and registeredMenus[list] and registeredMenus[list].onClose then
        registeredMenus[list].onClose('Escape')
    end

    TriggerEvent('global_menu:client:menuClosed')
end)

RegisterCommand('playerfocus', function()
    if headerShown then
        SetNuiFocus(true, true)
    end
end, false)

RegisterKeyMapping('playerfocus', 'Give Menu Focus', 'keyboard', 'LMENU')

exports('openMenu', function(data, sort, skipFirst, menuOptions)
    openKind = 'qb'
    openMenu(data, sort, skipFirst, menuOptions)
end)
exports('closeMenu', closeMenu)
exports('showHeader', showHeader)
exports('registerContext', registerContext)
exports('showContext', showContext)
exports('hideContext', hideContext)
exports('getOpenContextMenu', function()
    return openContextId
end)
exports('registerMenu', registerMenu)
exports('showMenu', showMenu)
exports('hideMenu', hideMenu)
exports('setMenuOptions', setMenuOptions)
exports('getOpenMenu', function()
    return openListId
end)
