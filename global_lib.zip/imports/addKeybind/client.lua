local keybinds = {}

local mt = {
    disabled = false,
    isPressed = false,
    defaultKey = '',
    defaultMapper = 'keyboard',
}

function mt:getCurrentKey()
    return GetControlInstructionalButton(0, self.hash, true):sub(3)
end

function mt:isControlPressed()
    return self.isPressed
end

function mt:disable(toggle)
    self.disabled = toggle
    self.isPressed = false
end

function mt:__index(index)
    if index == 'currentKey' then return self:getCurrentKey() end
    return mt[index]
end

function lib.addKeybind(data)
    data.hash = joaat('+' .. data.name) | 0x80000000
    setmetatable(data, mt)
    keybinds[data.name] = data

    RegisterCommand('+' .. data.name, function()
        if data.disabled or IsPauseMenuActive() then return end
        data.isPressed = true
        if data.onPressed then data:onPressed() end
    end, false)

    RegisterCommand('-' .. data.name, function()
        if data.disabled then return end
        data.isPressed = false
        if data.onReleased then data:onReleased() end
    end, false)

    RegisterKeyMapping('+' .. data.name, data.description or data.name, data.defaultMapper or 'keyboard', data.defaultKey or 'e')

    if data.secondaryKey then
        RegisterKeyMapping('~!+' .. data.name, data.description or data.name, data.secondaryMapper or data.defaultMapper or 'keyboard', data.secondaryKey)
    end

    return data
end

return lib.addKeybind
