local dict = {}
local path = GetResourceMetadata(cache.resource, 'locales_path', 0) or 'locales'

local function flatten(source, target, prefix)
    for key, value in pairs(source) do
        local full = prefix and (prefix .. '.' .. key) or key
        if type(value) == 'table' then
            flatten(value, target, full)
        else
            target[full] = value
        end
    end
end

function locale(str, ...)
    local value = dict[str]
    if not value then return str end
    if select('#', ...) > 0 then
        local ok, formatted = pcall(string.format, value, ...)
        return ok and formatted or value
    end
    return value
end

function lib.getLocales()
    return dict
end

function lib.getLocaleKey()
    return GetConvar('global:locale', GetConvar('ox:locale', 'en'))
end

function lib.locale(key)
    local lang = key or lib.getLocaleKey()
    local merged = {}

    local function read(name)
        local raw = LoadResourceFile(cache.resource, ('%s/%s.json'):format(path, name))
        if not raw then return end
        local decoded = json.decode(raw)
        if type(decoded) ~= 'table' then return end
        for k, v in pairs(decoded) do
            merged[k] = v
        end
    end

    read('en')
    if lang ~= 'en' then read(lang) end

    table.wipe(dict)
    flatten(merged, dict)
end

return lib.locale
