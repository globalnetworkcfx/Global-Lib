lib.math = math

function math.clamp(value, min, max)
    value = tonumber(value) or 0
    if min and value < min then return min end
    if max and value > max then return max end
    return value
end

return lib.math
