lib.print = {}

local function write(prefix, ...)
    print(prefix .. string.strjoin(' ', ...))
end

function lib.print.info(...)
    write('^2[global_lib]^7 ', ...)
end

function lib.print.warn(...)
    write('^3[global_lib]^7 ', ...)
end

function lib.print.error(...)
    write('^1[global_lib]^7 ', ...)
end

function lib.print.debug(...)
    write('^5[global_lib]^7 ', ...)
end

function lib.print.verbose(...)
    write('^7[global_lib]^7 ', ...)
end

return lib.print
