lib.cron = {}

local tasks = {}

local function fieldMatches(field, value)
    if field == '*' then return true end
    local step = field:match('^%*/(%d+)$')
    if step then return value % tonumber(step) == 0 end
    return tonumber(field) == value
end

function lib.cron.new(expression, job)
    local parts = {}
    for part in expression:gmatch('%S+') do
        parts[#parts + 1] = part
    end

    local task = {
        minute = parts[1] or '*',
        hour = parts[2] or '*',
        day = parts[3] or '*',
        month = parts[4] or '*',
        weekday = parts[5] or '*',
        job = job,
        last = nil,
    }

    tasks[#tasks + 1] = task
    return task
end

CreateThread(function()
    while true do
        local date = os.date('*t')
        local stamp = ('%d-%d-%d-%d'):format(date.year, date.yday, date.hour, date.min)

        for i = 1, #tasks do
            local task = tasks[i]
            if task.last ~= stamp
                and fieldMatches(task.minute, date.min)
                and fieldMatches(task.hour, date.hour)
                and fieldMatches(task.day, date.day)
                and fieldMatches(task.month, date.month)
                and (task.weekday == '*' or fieldMatches(task.weekday, date.wday - 1))
            then
                task.last = stamp
                local ok, err = pcall(task.job, task, date)
                if not ok then print(('^1global_lib cron: %s^0'):format(err)) end
            end
        end

        Wait(15000)
    end
end)

return lib.cron
