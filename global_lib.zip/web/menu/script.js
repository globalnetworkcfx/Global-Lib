let buttonParams = [];
let images = [];
let allowOverlayClose = false;
let overlayCloseTimeout = null;

/* Sonidos UI (locales) */
const s_swipe = new Audio('./sounds/swipe.mp3');
const s_click = new Audio('./sounds/click.mp3');
s_swipe.volume = 0.5;
s_click.volume = 0.5;

const playSound = (audio) => {
    try {
        audio.currentTime = 0;
        audio.play();
    } catch (e) { /* autoplay bloqueado, se ignora */ }
};

/* ----------------------------------------------------------------
   Título del menú
   ---------------------------------------------------------------- */
const renderMenuTitle = (title, titleIcon, subTitle) => {
    const $title = $('#menu-title');

    if (!title) {
        $title.addClass('hidden').attr('aria-hidden', 'true').empty();
        return;
    }

    const iconHtml = getIconHtml(titleIcon, true);
    const subTitleHtml = subTitle ? `<span class="menu-title-sub">${subTitle}</span>` : '';

    $title
        .removeClass('hidden')
        .attr('aria-hidden', 'false')
        .html(`
            <div class="menu-title-text">
                <span class="menu-title-main">${title}</span>
                ${subTitleHtml}
            </div>
            ${titleIcon ? `<div class="menu-title-icon">${iconHtml}</div>` : ''}
        `);
};

/* ----------------------------------------------------------------
   Íconos: soporta Iconify ("mdi:gun"), Font Awesome ("fa-solid fa-gun"),
   URL/imagen ("nui://...", "images/x.png") y fallback automático
   ---------------------------------------------------------------- */
const faToMdi = {
    'fa-gun': 'mdi:gun', 'fa-solid fa-gun': 'mdi:gun', 'fas fa-gun': 'mdi:gun',
    'fa-box': 'mdi:archive', 'fa-solid fa-box': 'mdi:archive', 'fas fa-box': 'mdi:archive',
    'fa-box-open': 'mdi:archive', 'fa-archive': 'mdi:archive', 'fa-cube': 'mdi:archive',
    'fa-briefcase': 'mdi:briefcase', 'fa-solid fa-briefcase': 'mdi:briefcase', 'fas fa-briefcase': 'mdi:briefcase',
    'fa-suitcase': 'mdi:briefcase', 'fa-bag-shopping': 'mdi:briefcase',
    'fa-user': 'mdi:account', 'fa-solid fa-user': 'mdi:account', 'fas fa-user': 'mdi:account',
    'fa-users': 'mdi:account-group', 'fas fa-users': 'mdi:account-group',
    'fa-car': 'mdi:car', 'fas fa-car': 'mdi:car', 'fa-solid fa-car': 'mdi:car',
    'fa-key': 'mdi:key', 'fas fa-key': 'mdi:key',
    'fa-handcuffs': 'mdi:handcuffs', 'fas fa-handcuffs': 'mdi:handcuffs',
    'fa-search': 'mdi:magnify', 'fas fa-search': 'mdi:magnify', 'fa-magnifying-glass': 'mdi:magnify',
    'fa-file': 'mdi:file-document', 'fa-file-alt': 'mdi:file-document',
    'fa-file-lines': 'mdi:file-document', 'fa-file-invoice': 'mdi:file-document',
    'fa-shield': 'mdi:shield-star', 'fa-shield-halved': 'mdi:shield-star',
    'fa-shield-alt': 'mdi:shield-star',
    'fa-wrench': 'mdi:wrench', 'fas fa-wrench': 'mdi:wrench',
    'fa-heart': 'mdi:heart', 'fas fa-heart': 'mdi:heart',
    'fa-garage': 'mdi:garage', 'fas fa-warehouse': 'mdi:warehouse',
};

/* APNG → Iconify estático (evita animaciones en el menú) */
const apngFileToMdi = {
    'cart.apng': 'mdi:cart',
    'drinks.apng': 'mdi:cup',
    'snack.apng': 'mdi:food-apple',
    'icecream.apng': 'mdi:ice-cream',
    'cash.apng': 'mdi:cash',
    'card.apng': 'mdi:credit-card',
    'close.apng': 'mdi:close',
    'trash.apng': 'mdi:trash-can',
    'back.apng': 'mdi:arrow-left',
    'list.apng': 'mdi:format-list-bulleted',
    'quantity.apng': 'mdi:numeric',
    'final.apng': 'mdi:cash-check',
    'cancel.apng': 'mdi:cancel',
    'beer.apng': 'mdi:beer',
    'alcohol.apng': 'mdi:glass-wine',
};

function resolveApngToStaticIcon(icon) {
    if (!icon || typeof icon !== 'string') return null;
    if (!/\.apng(\?|#|$)/i.test(icon)) return null;
    const file = (icon.split('/').pop() || '').split('?')[0].toLowerCase();
    return apngFileToMdi[file] || 'mdi:shield-check';
}

function freezeApngImage(img) {
    if (!img || img.dataset.apngFrozen === '1') return;
    const src = img.currentSrc || img.src || '';
    if (!/\.apng(\?|#|$)/i.test(src)) return;
    try {
        const canvas = document.createElement('canvas');
        const w = img.naturalWidth || img.width || 64;
        const h = img.naturalHeight || img.height || 64;
        if (!w || !h) return;
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        img.dataset.apngFrozen = '1';
        img.src = canvas.toDataURL('image/png');
    } catch (e) { /* cross-origin / CEF */ }
}

window.freezeApngIcon = freezeApngImage;

function resolveFaToMdi(icon) {
    if (!icon || typeof icon !== 'string') return null;
    const k = icon.trim().toLowerCase();
    if (faToMdi[k]) return faToMdi[k];
    if (k.indexOf('fa-solid ') === 0 || k.indexOf('fa-regular ') === 0 || k.indexOf('fa-brands ') === 0
        || k.indexOf('fas ') === 0 || k.indexOf('far ') === 0 || k.indexOf('fab ') === 0) {
        return null;
    }
    if (k.indexOf('fa-') !== -1) return 'mdi:shield-check';
    return null;
}

function getIconHtml(icon, isHeader) {
    if (!icon) {
        return isHeader
            ? '<span class="iconify" data-icon="mdi:shield-star" data-width="22" data-height="22"></span>'
            : '';
    }

    const apngStatic = resolveApngToStaticIcon(icon);
    if (apngStatic) {
        const size = isHeader ? '42' : '18';
        return `<span class="iconify" data-icon="${apngStatic}" data-width="${size}" data-height="${size}"></span>`;
    }

    const isUrl = typeof icon === 'string' && (icon.indexOf('/') !== -1 || icon.indexOf('nui://') === 0);
    if (isUrl) {
        return `<img src="${icon}" class="icon-img" onload="window.freezeApngIcon&&window.freezeApngIcon(this)" onerror="this.onerror=null;this.parentElement.innerHTML='<span class=\\'iconify\\' data-icon=\\'mdi:shield-check\\' data-width=\\'26\\' data-height=\\'26\\'></span>';">`;
    }

    if (typeof icon === 'string' && icon.indexOf(':') !== -1) {
        const size = isHeader ? '42' : '18';
        return `<span class="iconify" data-icon="${icon}" data-width="${size}" data-height="${size}"></span>`;
    }

    if (isFontAwesomeIcon(icon)) {
        const mdi = resolveFaToMdi(icon);
        if (mdi) {
            const size = isHeader ? '42' : '18';
            return `<span class="iconify" data-icon="${mdi}" data-width="${size}" data-height="${size}"></span>`;
        }
        return `<i class="${icon} icon-fa"></i>`;
    }

    return `<i class="${icon} icon-fa"></i>`;
}

function isFontAwesomeIcon(icon) {
    if (!icon || typeof icon !== 'string') return false;
    const t = icon.trim().toLowerCase();
    return t.indexOf('fa-') !== -1 || t.indexOf('fas ') === 0 || t.indexOf('far ') === 0 || t.indexOf('fab ') === 0;
}

/* ----------------------------------------------------------------
   Render de un botón / header de sección
   ---------------------------------------------------------------- */
const getButtonRender = (header, message, id, isMenuHeader, isDisabled, icon, color) => {
    if (isMenuHeader) {
        const iconHtml = icon ? getIconHtml(icon, true) : '';
        return `
            <div class="title" id="${id}" data-is-header="true">
                <div class="column">
                    <div class="header">${header}</div>
                    ${message ? `<div class="text">${message}</div>` : ''}
                </div>
                ${icon ? `<div class="icon">${iconHtml}</div>` : ''}
            </div>
        `;
    }

    const iconHtml = getIconHtml(icon, false);
    const colorStyle = color
        ? `style="background-color: ${color} !important; box-shadow: 0 2px 6px ${color}40;"`
        : '';

    return `
        <div class="button ${isDisabled ? 'disabled' : ''}" id="${id}" ${colorStyle}>
            <div class="icon">${iconHtml}</div>
            <div class="column">
                <div class="header">${header}</div>
                ${message ? `<div class="text">${message}</div>` : ''}
            </div>
        </div>
    `;
};

/* ----------------------------------------------------------------
   Abrir / cerrar menú
   ---------------------------------------------------------------- */
/* ----------------------------------------------------------------
   Abrir / cerrar menú (con protección anti spam open/close)
   ---------------------------------------------------------------- */
let isClosingMenu = false;
let isOpeningMenu = false;
let menuAnimToken = 0;
let closeFallbackTimeout = null;
let openAnimTimeout = null;

const clearMenuAnimTimers = () => {
    if (closeFallbackTimeout) {
        clearTimeout(closeFallbackTimeout);
        closeFallbackTimeout = null;
    }
    if (openAnimTimeout) {
        clearTimeout(openAnimTimeout);
        openAnimTimeout = null;
    }
    $('#buttons').off('animationend.closeMenu animationend.openMenu');
};

const hardResetMenuVisual = () => {
    clearMenuAnimTimers();
    isClosingMenu = false;
    isOpeningMenu = false;
    const $buttons = $('#buttons');
    $buttons.removeClass('menu-open menu-close is-visible');
    $buttons.css('animation', 'none');
    void $buttons[0].offsetWidth;
    $buttons.css('animation', '');
};

const openMenu = (payload = null) => {
    const data = Array.isArray(payload) ? payload : (payload && payload.data) || [];
    const title = Array.isArray(payload) ? null : payload && payload.title;
    const titleIcon = Array.isArray(payload) ? null : payload && payload.titleIcon;
    const subTitle = Array.isArray(payload) ? null : payload && payload.subTitle;

    const $overlay = $('#menu-overlay');
    const $buttons = $('#buttons');
    const $content = $('.menu-content');

    // Cancelar cualquier cierre/apertura pendiente
    if (overlayCloseTimeout) clearTimeout(overlayCloseTimeout);
    allowOverlayClose = false;
    menuAnimToken += 1;
    const token = menuAnimToken;
    hardResetMenuVisual();

    renderMenuTitle(title, titleIcon, subTitle);

    let html = '';
    buttonParams = [];
    images = [];

    data.forEach((item, index) => {
        if (item.hidden) return;
        const header = item.header;
        const message = item.txt || item.text;
        const isMenuHeader = item.isMenuHeader;
        const isDisabled = item.disabled;
        const icon = item.icon;
        const color = item.color || item.bgColor || null;

        images[index] = item;
        html += getButtonRender(header, message, index, isMenuHeader, isDisabled, icon, color);
        if (item.params) buttonParams[index] = item.params;
    });

    $content.html(html);
    $overlay.addClass('show');

    isOpeningMenu = true;
    // Esperar 2 frames con layout ya montado (título + botones) y luego animar
    requestAnimationFrame(() => {
        if (token !== menuAnimToken) return;
        void $buttons[0].offsetHeight;
        requestAnimationFrame(() => {
            if (token !== menuAnimToken) return;
            $buttons.addClass('is-visible menu-open');
        });
    });
    playSound(s_swipe);

    openAnimTimeout = setTimeout(() => {
        if (token !== menuAnimToken) return;
        isOpeningMenu = false;
        openAnimTimeout = null;
    }, 620);

    overlayCloseTimeout = setTimeout(function () {
        if (token !== menuAnimToken) return;
        allowOverlayClose = true;
        overlayCloseTimeout = null;
    }, 600);

    $('.button:not(.disabled)').first().addClass('selected');

    $('.button').off('click').on('click', function () {
        const target = $(this);
        if (!target.hasClass('disabled') && !isClosingMenu) {
            playSound(s_click);
            postData(target.attr('id'));
        }
    });

    $('.button').off('mouseenter').on('mouseenter', function () {
        if ($(this).hasClass('disabled') || isClosingMenu) return;
        $('.button.selected').removeClass('selected');
        $(this).addClass('selected');
    });
};

const closeMenu = (instant = false) => {
    $('#imageHover').css('display', 'none');
    const $overlay = $('#menu-overlay');
    const $buttons = $('#buttons');
    const $content = $('.menu-content');
    const $title = $('#menu-title');

    const resetMenu = (token) => {
        if (token !== undefined && token !== menuAnimToken) return;
        clearMenuAnimTimers();
        isClosingMenu = false;
        isOpeningMenu = false;
        $overlay.removeClass('show');
        $buttons.removeClass('menu-open menu-close is-visible');
        $buttons.css('animation', '');
        $content.html('');
        $title.addClass('hidden').attr('aria-hidden', 'true').empty();
        buttonParams = [];
        images = [];
    };

    const menuVisible = $overlay.hasClass('show') || $buttons.hasClass('is-visible') || $buttons.hasClass('menu-open');

    if (!menuVisible) {
        resetMenu();
        return;
    }

    if (instant) {
        menuAnimToken += 1;
        hardResetMenuVisual();
        resetMenu();
        return;
    }

    // Si ya está cerrando, no reiniciar (evita cortar la animación)
    if (isClosingMenu) return;

    // Si se está abriendo, cancelar apertura y cerrar desde el estado actual
    menuAnimToken += 1;
    const token = menuAnimToken;
    clearMenuAnimTimers();
    isOpeningMenu = false;
    isClosingMenu = true;
    allowOverlayClose = false;

    playSound(s_swipe);

    // Si estaba abriendo a medias, forzar estado visible y lanzar cierre limpio
    $buttons.removeClass('menu-open');
    $buttons.css('animation', 'none');
    void $buttons[0].offsetWidth;
    $buttons.css('animation', '');
    $buttons.addClass('is-visible menu-close');

    closeFallbackTimeout = setTimeout(() => {
        resetMenu(token);
    }, 520);

    $buttons.off('animationend.closeMenu').one('animationend.closeMenu', function (e) {
        if (e.target !== $buttons[0]) return;
        if (token !== menuAnimToken) return;
        clearTimeout(closeFallbackTimeout);
        closeFallbackTimeout = null;
        resetMenu(token);
    });
};

/* ----------------------------------------------------------------
   Actualizar una opción ya renderizada (UPDATE_OPTION)
   ---------------------------------------------------------------- */
const updateMenu = (option, key, value) => {
    const $opt = $(`#${option - 1}`);
    if (!$opt.length) return;

    switch (key) {
        case 'header':
            $opt.find('.header').html(value);
            break;
        case 'txt':
        case 'text':
            $opt.find('.text').html(value);
            break;
        case 'icon':
            $opt.find('.icon').html(getIconHtml(value, $opt.hasClass('title')));
            break;
        case 'disabled':
            $opt.toggleClass('disabled', !!value);
            break;
        case 'hidden':
            $opt.toggle(!value);
            break;
        default:
            break;
    }
};

/* ----------------------------------------------------------------
   Comunicación con el cliente (Lua/NUI)
   ---------------------------------------------------------------- */
const postData = (id) => {
    $.post(`https://${GetParentResourceName()}/menuClicked`, JSON.stringify(parseInt(id) + 1));
    return closeMenu();
};

const cancelMenu = () => {
    $.post(`https://${GetParentResourceName()}/menuClosed`);
    return closeMenu();
};

window.addEventListener('message', (event) => {
    const data = event.data;
    const buttons = data.data;
    const action = data.action;
    if (!action) return;

    switch (action) {
        case 'menu:open':
        case 'menu:header':
            if (!buttons || !Array.isArray(buttons) || buttons.length === 0) return;
            return openMenu({
                data: buttons,
                title: data.title || null,
                titleIcon: data.titleIcon || null,
                subTitle: data.subTitle || null,
            });
        case 'menu:close':
            return closeMenu(false);
        case 'menu:update':
            return updateMenu(data.option, data.key, data.value);
        case 'menu:hide':
            return closeMenu(false);
        case 'menu:show':
            $('#menu-overlay').addClass('show');
            return;
        default:
            return;
    }
});

/* Vista previa de imagen al pasar el mouse sobre un botón con item.image */
window.addEventListener('mousemove', (event) => {
    const $target = $(event.target);
    if ($target.closest('.button:hover').length && $('.button').is(':visible')) {
        const id = event.target.id;
        if (!images[id]) return;
        if (images[id].image) {
            $('#image').attr('src', images[id].image);
            $('#imageHover').css('display', 'block');
        }
    } else {
        $('#imageHover').css('display', 'none');
    }
});

/* Clic fuera del panel cierra el menú (con pequeño delay anti-doble-clic) */
$('#menu-overlay').on('click', function (e) {
    if (e.target.id !== 'menu-overlay') return;
    if (!allowOverlayClose) return;
    cancelMenu();
});

$('#container').on('click', function (e) {
    e.stopPropagation();
});

/* Clic derecho o Escape cancelan/cierran el menú */
document.addEventListener('mousedown', function (event) {
    if (event.button === 2 && $('#menu-overlay').hasClass('show')) {
        cancelMenu();
    }
});

document.addEventListener('keyup', function (event) {
    if (event.key === 'Escape' && $('#menu-overlay').hasClass('show')) {
        cancelMenu();
    }
});