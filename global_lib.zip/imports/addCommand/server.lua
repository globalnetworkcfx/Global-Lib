local function allowed(source, restricted)
    if not restricted or source == 0 then return true end
    if type(restricted) == 'string' then
        return IsPlayerAceAllowed(source, restricted)
    end
    if type(restricted) == 'table' then
        for i = 1, #restricted do
            if IsPlayerAceAllowed(source, restricted[i]) then return true end
        end
        return false
    end
    return true
end

local function parse(source, args, raw, params)
    if not params then return args end

    local parsed = {}
    for i = 1, #params do
        local param = params[i]
        local arg = args[i]
        local value = arg

        if param.type == 'number' then
            value = tonumber(arg)
        elseif param.type == 'playerId' then
            value = arg == 'me' and source or tonumber(arg)
            if not value or not GetPlayerName(value) then value = nil end
        elseif param.type == 'longString' and i == #params and arg then
            local start = raw:find(arg, 1, true)
            value = start and raw:sub(start) or arg
        end

        if value == nil and not param.optional then
            return nil
        end

        parsed[param.name] = value
    end

    return parsed
end

function lib.addCommand(commandName, properties, cb)
    local names = type(commandName) == 'table' and commandName or { commandName }
    properties = properties or {}

    local function handler(source, args, raw)
        if not allowed(source, properties.restricted) then return end
        local parsed = parse(source, args, raw, properties.params)
        if not parsed then return end
        cb(source, parsed, raw)
    end

    for i = 1, #names do
        RegisterCommand(names[i], handler, false)
    end
end

return lib.addCommand
