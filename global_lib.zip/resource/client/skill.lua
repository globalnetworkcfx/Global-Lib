local keys = {
    w = 32,
    a = 34,
    s = 33,
    d = 35,
    e = 38,
    q = 44,
}

local function durationFor(level)
    if level == 'easy' then return 3500 end
    if level == 'medium' then return 2200 end
    if level == 'hard' then return 1400 end
    if type(level) == 'table' and level.areaSize then
        return math.max(800, math.floor(level.areaSize * 18))
    end
    return 2000
end

local function skillCheck(difficulty, inputs)
    local steps = type(difficulty) == 'table' and difficulty or { difficulty or 'easy' }
    local options = inputs or { 'e' }

    for i = 1, #steps do
        local keyName = options[((i - 1) % #options) + 1]
        local control = keys[string.lower(tostring(keyName))] or 38
        local limit = GetGameTimer() + durationFor(steps[i])
        local pressed = false

        while GetGameTimer() < limit do
            if IsControlJustPressed(0, control) or IsDisabledControlJustPressed(0, control) then
                pressed = true
                break
            end
            Wait(0)
        end

        if not pressed then return false end
    end

    return true
end

exports('skillCheck', skillCheck)
exports('skillCheckActive', function()
    return false
end)
exports('cancelSkillCheck', function() end)
