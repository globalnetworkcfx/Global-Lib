document.addEventListener("DOMContentLoaded", () => {
    var ProgressBar = {
        init: function () {
            this.progressLabel = document.getElementById("progress-label");
            this.progressBar = document.getElementById("progress-bar");
            this.progressContainer = document.querySelector(".progress-container");
            this.animationFrameRequest = null;
            this.setupListeners();
        },

        setupListeners: function () {
            window.addEventListener("message", function (event) {
                if (event.data.action === "progress") {
                    ProgressBar.update(event.data);
                } else if (event.data.action === "cancel") {
                    ProgressBar.cancel();
                }
            });
        },

        update: function (data) {
            if (this.animationFrameRequest) {
                cancelAnimationFrame(this.animationFrameRequest);
            }
            clearTimeout(this.cancelledTimer);

            this.progressContainer.classList.remove("cancelled", "hide");
            this.progressLabel.textContent = (data.label || "Cargando...").toUpperCase();
            this.progressBar.style.width = "0%";
            this.progressContainer.style.display = "block";
            this.progressContainer.classList.add("show");

            let startTime = Date.now();
            let duration = parseInt(data.duration, 10);

            const animateProgress = () => {
                let timeElapsed = Date.now() - startTime;
                let progress = timeElapsed / duration;
                if (progress > 1) progress = 1;
                this.progressBar.style.width = Math.round(progress * 100) + "%";
                if (progress < 1) {
                    this.animationFrameRequest = requestAnimationFrame(animateProgress);
                } else {
                    this.onComplete();
                }
            };
            this.animationFrameRequest = requestAnimationFrame(animateProgress);
        },

        cancel: function () {
            if (this.animationFrameRequest) {
                cancelAnimationFrame(this.animationFrameRequest);
                this.animationFrameRequest = null;
            }
            this.progressContainer.classList.add("cancelled");
            this.progressLabel.textContent = "CANCELADO";
            this.progressBar.style.width = "100%";
            this.cancelledTimer = setTimeout(this.onCancel.bind(this), 1000);
        },

        onComplete: function () {
            this.doHide(true);
        },

        onCancel: function () {
            this.doHide(false);
        },

        doHide: function (shouldPost) {
            var self = this;
            this.progressContainer.classList.remove("show");
            this.progressContainer.classList.add("hide");
            setTimeout(function () {
                self.progressContainer.style.display = "none";
                self.progressContainer.classList.remove("hide", "cancelled");
                self.progressBar.style.width = "0%";
                if (shouldPost) {
                    self.postAction("FinishAction");
                }
            }, 250);
        },

        postAction: function (action) {
            fetch(`https://${GetParentResourceName()}/${action}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({}),
            });
        },
    };

    ProgressBar.init();
});
