function lib.waitFor(cb, errMessage, timeout)
    local value = cb()
    if value then return value end

    local started = GetGameTimer()
    timeout = timeout or 1000

    while true do
        Wait(0)
        value = cb()
        if value then return value end
        if GetGameTimer() - started > timeout then
            return error(errMessage or 'waitFor timed out', 2)
        end
    end
end

return lib.waitFor
