local Action = {
    name = '',
    duration = 0,
    label = '',
    useWhileDead = false,
    canCancel = true,
    controlDisables = {
        disableMovement = false,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = false,
    },
    animation = {},
    prop = {},
    propTwo = {},
}

local isDoingAction = false
local wasCancelled = false
local prop_net = nil
local propTwo_net = nil
local isAnim = false
local isProp = false
local isPropTwo = false
local previousBusy = false

local controls = {
    disableMouse = { 1, 2, 106 },
    disableMovement = { 30, 31, 36, 21, 75 },
    disableCarMovement = { 63, 64, 71, 72 },
    disableCombat = { 24, 25, 37, 47, 58, 140, 141, 142, 143, 263, 264, 257 },
}

local function loadAnimDict(dict)
    RequestAnimDict(dict)
    local timeout = GetGameTimer() + 5000
    while not HasAnimDictLoaded(dict) do
        if GetGameTimer() > timeout then return false end
        Wait(5)
    end
    return true
end

local function loadModel(model)
    local hash = type(model) == 'number' and model or joaat(model)
    if not IsModelValid(hash) then return nil end
    RequestModel(hash)
    local timeout = GetGameTimer() + 5000
    while not HasModelLoaded(hash) do
        if GetGameTimer() > timeout then return nil end
        Wait(5)
    end
    return hash
end

local function createAndAttachProp(prop, ped)
    local hash = loadModel(prop.model)
    if not hash then return nil end

    local coords = GetEntityCoords(ped)
    local propEntity = CreateObject(hash, coords.x, coords.y, coords.z, true, true, true)
    local netId = ObjToNet(propEntity)
    SetNetworkIdExistsOnAllMachines(netId, true)
    NetworkUseHighPrecisionBlending(netId, true)
    SetNetworkIdCanMigrate(netId, false)
    local boneIndex = GetPedBoneIndex(ped, prop.bone or 60309)
    local coords = prop.coords or vec3(0.0, 0.0, 0.0)
    local rotation = prop.rotation or vec3(0.0, 0.0, 0.0)
    AttachEntityToEntity(
        propEntity, ped, boneIndex,
        coords.x, coords.y, coords.z,
        rotation.x, rotation.y, rotation.z,
        true, true, false, true, 0, true
    )
    SetModelAsNoLongerNeeded(hash)
    return netId
end

local function disableControls()
    CreateThread(function()
        while isDoingAction do
            for disableType, isEnabled in pairs(Action.controlDisables) do
                if isEnabled and controls[disableType] then
                    for i = 1, #controls[disableType] do
                        DisableControlAction(0, controls[disableType][i], true)
                    end
                end
            end
            if Action.controlDisables.disableCombat then
                DisablePlayerFiring(PlayerId(), true)
            end
            Wait(0)
        end
    end)
end

local function setBusy(state)
    local playerState = LocalPlayer.state
    if state then
        previousBusy = playerState.invBusy
        playerState:set('invBusy', true, true)
        playerState:set('inv_busy', true, true)
    else
        playerState:set('invBusy', previousBusy, true)
        playerState:set('inv_busy', false, true)
    end
end

local function StartActions()
    local ped = PlayerPedId()
    if not isDoingAction then return end

    if not isAnim and Action.animation then
        if Action.animation.task then
            TaskStartScenarioInPlace(ped, Action.animation.task, 0, true)
        else
            local anim = Action.animation
            if anim.animDict and anim.anim and DoesEntityExist(ped) and not IsEntityDead(ped) then
                if loadAnimDict(anim.animDict) then
                    TaskPlayAnim(ped, anim.animDict, anim.anim, 3.0, 3.0, -1, anim.flags or 1, 0, false, false, false)
                end
            end
        end
        isAnim = true
    end

    if not isProp and Action.prop and Action.prop.model then
        prop_net = createAndAttachProp(Action.prop, ped)
        isProp = true
    end

    if not isPropTwo and Action.propTwo and Action.propTwo.model then
        propTwo_net = createAndAttachProp(Action.propTwo, ped)
        isPropTwo = true
    end

    disableControls()
end

local function ActionCleanup()
    local ped = PlayerPedId()
    if Action.animation then
        if Action.animation.task or (Action.animation.animDict and Action.animation.anim) then
            if Action.animation.animDict and Action.animation.anim then
                StopAnimTask(ped, Action.animation.animDict, Action.animation.anim, 1.0)
            end
            ClearPedSecondaryTask(ped)
        else
            ClearPedTasks(ped)
        end
    end

    if prop_net then
        local obj = NetToObj(prop_net)
        if DoesEntityExist(obj) then
            DetachEntity(obj, true, true)
            DeleteObject(obj)
        end
    end

    if propTwo_net then
        local obj = NetToObj(propTwo_net)
        if DoesEntityExist(obj) then
            DetachEntity(obj, true, true)
            DeleteObject(obj)
        end
    end

    prop_net = nil
    propTwo_net = nil
    isDoingAction = false
    wasCancelled = false
    isAnim = false
    isProp = false
    isPropTwo = false
    setBusy(false)
end

local function shouldInterrupt(action)
    if not action.oxChecks then return false end
    local ped = PlayerPedId()
    if not action.useWhileDead and IsEntityDead(ped) then return true end
    if not action.allowRagdoll and IsPedRagdoll(ped) then return true end
    if not action.allowCuffed and IsPedCuffed(ped) then return true end
    if not action.allowFalling and IsPedFalling(ped) then return true end
    if not action.allowSwimming and IsPedSwimming(ped) then return true end
    return false
end

local function StartProgress(action, onStart, onTick, onFinish)
    local playerPed = PlayerPedId()
    local isPlayerDead = IsEntityDead(playerPed)

    if (isPlayerDead and not action.useWhileDead) or isDoingAction then
        if onFinish then onFinish(true) end
        return false
    end

    isDoingAction = true
    wasCancelled = false
    setBusy(true)
    Action = action

    SendNUIMessage({
        action = 'progress',
        duration = action.duration,
        label = action.label,
    })

    StartActions()

    CreateThread(function()
        if onStart then onStart() end

        local endsAt = GetGameTimer() + (tonumber(action.duration) or 0) + 1500

        while isDoingAction do
            Wait(0)

            if GetGameTimer() > endsAt then
                wasCancelled = false
                isDoingAction = false
                break
            end

            if onTick then onTick() end

            if action.canCancel and (IsControlJustPressed(0, 200) or IsControlJustPressed(0, 73)) then
                wasCancelled = true
                isDoingAction = false
                break
            end

            if shouldInterrupt(action) or (IsEntityDead(playerPed) and not action.useWhileDead) then
                wasCancelled = true
                isDoingAction = false
                break
            end
        end

        local cancelled = wasCancelled
        ActionCleanup()
        if cancelled then
            SendNUIMessage({ action = 'cancel' })
        end

        if onFinish then onFinish(cancelled) end
    end)

    return true
end

RegisterNUICallback('FinishAction', function(_, cb)
    cb('ok')
    if not isDoingAction then return end
    wasCancelled = false
    isDoingAction = false
end)

local function cancelProgress()
    if not isDoingAction then return end
    wasCancelled = true
    isDoingAction = false
end

RegisterNetEvent('progressbar:client:ToggleBusyness', function(bool)
    isDoingAction = bool
end)

RegisterNetEvent('progressbar:client:progress', function(action, finish)
    StartProgress(action, nil, nil, finish)
end)

RegisterNetEvent('progressbar:client:ProgressWithStartEvent', function(action, start, finish)
    StartProgress(action, start, nil, finish)
end)

RegisterNetEvent('progressbar:client:ProgressWithTickEvent', function(action, tick, finish)
    StartProgress(action, nil, tick, finish)
end)

RegisterNetEvent('progressbar:client:ProgressWithStartAndTick', function(action, start, tick, finish)
    StartProgress(action, start, tick, finish)
end)

RegisterNetEvent('progressbar:client:cancel', function()
    cancelProgress()
end)

local function Progress(action, finish)
    return StartProgress(action, nil, nil, finish)
end

local function ProgressWithStartEvent(action, start, finish)
    return StartProgress(action, start, nil, finish)
end

local function ProgressWithTickEvent(action, a, b, c)
    if type(c) == 'function' then
        return StartProgress(action, a, b, c)
    end
    return StartProgress(action, nil, a, b)
end

local function ProgressWithStartAndTick(action, start, tick, finish)
    return StartProgress(action, start, tick, finish)
end

local function isDoingSomething()
    return isDoingAction
end

local function vecOr(value, fallback)
    if value then return value end
    return fallback
end

local function buildAction(data)
    local action = {
        duration = data.duration,
        label = data.label or 'Cargando...',
        useWhileDead = data.useWhileDead,
        canCancel = data.canCancel ~= false,
        allowRagdoll = data.allowRagdoll,
        allowCuffed = data.allowCuffed,
        allowFalling = data.allowFalling,
        allowSwimming = data.allowSwimming,
        oxChecks = true,
        controlDisables = {
            disableMovement = data.disable and data.disable.move or false,
            disableCarMovement = data.disable and data.disable.car or false,
            disableMouse = data.disable and data.disable.mouse or false,
            disableCombat = data.disable and data.disable.combat or false,
        },
        animation = {},
        prop = {},
        propTwo = {},
    }

    if data.anim then
        action.animation = {
            animDict = data.anim.dict,
            anim = data.anim.clip,
            flags = data.anim.flag or 49,
            task = data.anim.scenario,
        }
    end

    if data.prop then
        local props = data.prop.model and { data.prop } or data.prop
        local first = props[1]
        local second = props[2]

        if first then
            action.prop = {
                model = first.model,
                bone = first.bone,
                coords = vecOr(first.pos or first.coords, vec3(0.0, 0.0, 0.0)),
                rotation = vecOr(first.rot or first.rotation, vec3(0.0, 0.0, 0.0)),
            }
        end

        if second then
            action.propTwo = {
                model = second.model,
                bone = second.bone,
                coords = vecOr(second.pos or second.coords, vec3(0.0, 0.0, 0.0)),
                rotation = vecOr(second.rot or second.rotation, vec3(0.0, 0.0, 0.0)),
            }
        end
    end

    return action
end

local function runOxProgress(data)
    while isDoingAction do Wait(0) end

    local ped = PlayerPedId()
    if not data.useWhileDead and IsEntityDead(ped) then return end
    if not data.allowRagdoll and IsPedRagdoll(ped) then return end
    if not data.allowCuffed and IsPedCuffed(ped) then return end
    if not data.allowFalling and IsPedFalling(ped) then return end
    if not data.allowSwimming and IsPedSwimming(ped) then return end

    local p = promise.new()
    local started = StartProgress(buildAction(data), nil, nil, function(cancelled)
        p:resolve(not cancelled)
    end)

    if not started then return false end
    return Citizen.Await(p)
end

exports('Progress', Progress)
exports('ProgressWithStartEvent', ProgressWithStartEvent)
exports('ProgressWithTickEvent', ProgressWithTickEvent)
exports('ProgressWithStartAndTick', ProgressWithStartAndTick)
exports('isDoingSomething', isDoingSomething)
exports('progressBar', runOxProgress)
exports('progressCircle', runOxProgress)

exports('cancelProgress', function()
    if not isDoingAction then
        error('No progress bar is active')
    end
    cancelProgress()
end)

exports('progressActive', function()
    return isDoingAction
end)

RegisterCommand('cancelprogress', function()
    if not isDoingAction or Action.canCancel == false then return end
    cancelProgress()
end, false)

RegisterKeyMapping('cancelprogress', 'Cancelar barra de progreso', 'keyboard', 'x')
