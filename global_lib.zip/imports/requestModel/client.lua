function lib.waitFor(cb, errMessage, timeout)
    local value = cb()
    if value then return value end

    local started = GetGameTimer()
    timeout = timeout or 1000

    while true do
        Wait(0)
        value = cb()
        if value then return value end
        if GetGameTimer() - started > timeout then
            return error(errMessage or 'waitFor timed out', 2)
        end
    end
end

local function request(requestFn, hasFn, asset, timeout)
    if hasFn(asset) then return asset end
    requestFn(asset)
    local started = GetGameTimer()
    timeout = timeout or 5000

    while not hasFn(asset) do
        if GetGameTimer() - started > timeout then
            return error(('failed to load %s'):format(asset), 2)
        end
        Wait(0)
    end

    return asset
end

function lib.requestAnimDict(dict, timeout)
    if not dict then return end
    if HasAnimDictLoaded(dict) then return dict end
    return request(RequestAnimDict, HasAnimDictLoaded, dict, timeout)
end

function lib.requestModel(model, timeout)
    local hash = type(model) == 'number' and model or joaat(model)
    if not IsModelValid(hash) then
        return error(('invalid model %s'):format(model), 2)
    end
    if HasModelLoaded(hash) then return hash end
    RequestModel(hash)
    local started = GetGameTimer()
    timeout = timeout or 5000
    while not HasModelLoaded(hash) do
        if GetGameTimer() - started > timeout then
            return error(('failed to load model %s'):format(model), 2)
        end
        Wait(0)
    end
    return hash
end

return lib.requestModel
