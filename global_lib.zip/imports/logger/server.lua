function lib.logger(source, event, message, ...)
    print(('[global_lib] %s | %s | %s'):format(tostring(source), tostring(event), tostring(message)))
end

return lib.logger
