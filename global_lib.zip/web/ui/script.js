const notifyRoot = document.createElement('div');
notifyRoot.id = 'notify-root';
document.body.appendChild(notifyRoot);

const textui = document.createElement('div');
textui.id = 'textui';
document.body.appendChild(textui);

window.addEventListener('message', (event) => {
    const payload = event.data || {};

    if (payload.action === 'notify') {
        const data = payload.data || {};
        const card = document.createElement('div');
        card.className = `notify ${data.type || 'inform'}`;
        card.innerHTML = `${data.title ? `<h4>${data.title}</h4>` : ''}<p>${data.description || ''}</p>`;
        notifyRoot.appendChild(card);
        setTimeout(() => card.remove(), data.duration || 4000);
    }

    if (payload.action === 'textui') {
        const data = payload.data || {};
        textui.textContent = data.text || '';
        textui.className = data.position && String(data.position).includes('right') ? 'right' : '';
        textui.style.display = 'block';
    }

    if (payload.action === 'textui:hide') {
        textui.style.display = 'none';
    }

    if (payload.action === 'clipboard') {
        const value = payload.data || '';
        const node = document.createElement('textarea');
        node.value = value;
        document.body.appendChild(node);
        node.select();
        document.execCommand('copy');
        node.remove();
    }
});
