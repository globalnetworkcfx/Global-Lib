local points = {}
local nextId = 0
local closestPoint

local function remove(self)
    points[self.id] = nil
    if closestPoint and closestPoint.id == self.id then
        closestPoint = nil
    end
end

function lib.points.new(data)
    nextId += 1
    data.id = nextId
    data.coords = data.coords
    data.distance = data.distance or 5.0
    data.remove = remove
    points[data.id] = data
    return data
end

function lib.points.getClosestPoint()
    return closestPoint
end

function lib.points.getAllPoints()
    return points
end

CreateThread(function()
    while true do
        local ped = cache.ped or PlayerPedId()
        local coords = GetEntityCoords(ped)
        local closest
        local sleep = 500

        for _, point in pairs(points) do
            local distance = #(coords - point.coords)
            point.currentDistance = distance
            local radius = point.distance or point.radius or 5.0

            if distance <= radius then
                sleep = 0
                if not closest or distance < closest.currentDistance then
                    if closest then closest.isClosest = nil end
                    point.isClosest = true
                    closest = point
                end

                if point.inside ~= true then
                    point.inside = true
                    if point.onEnter then point:onEnter() end
                end

                if point.nearby then point:nearby() end
            elseif point.inside then
                point.inside = nil
                point.isClosest = nil
                if point.onExit then point:onExit() end
            end
        end

        closestPoint = closest
        Wait(sleep)
    end
end)

return lib.points
