fx_version 'cerulean'
use_experimental_fxv2_oal 'yes'
lua54 'yes'
game 'gta5'

name 'global_lib'
author 'Global Network'
version '1.1.0'
description 'Libreria Global'

ui_page 'web/index.html'

files {
    'init.lua',
    'imports/**/*.lua',
    'web/index.html',
    'web/**/*',
}

shared_script 'resource/shared.lua'

client_scripts {
    'resource/client/progress.lua',
    'resource/client/input.lua',
    'resource/client/menu.lua',
    'resource/client/ui.lua',
    'resource/client/skill.lua',
}
