local pending = {}
local cbEvent = '__global_cb_%s'
local timeoutMs = GetConvarInt('global:callbackTimeout', 300000)
local registered = {}

RegisterNetEvent(cbEvent:format(cache.resource), function(key, ...)
    local cb = pending[key]
    if not cb then return end
    pending[key] = nil
    cb(...)
end)

local function trigger(_, event, playerId, cb, ...)
    local key
    repeat
        key = ('%s:%s:%s'):format(event, math.random(0, 100000), playerId)
    until not pending[key]

    TriggerClientEvent(cbEvent:format(event), playerId, cache.resource, key, ...)

    local awaiter = not cb and promise.new()

    pending[key] = function(response, ...)
        if response == 'cb_invalid' then
            local message = ("callback '%s' does not exist"):format(event)
            if awaiter then return awaiter:reject(message) end
            return error(message)
        end

        local packed = { response, ... }
        if awaiter then return awaiter:resolve(packed) end
        if cb then cb(table.unpack(packed)) end
    end

    if awaiter then
        SetTimeout(timeoutMs, function()
            if pending[key] then
                pending[key] = nil
                awaiter:reject(("callback '%s' timed out"):format(event))
            end
        end)
        return table.unpack(Citizen.Await(awaiter))
    end
end

lib.callback = setmetatable({}, {
    __call = function(_, event, playerId, cb, ...)
        return trigger(_, event, playerId, cb, ...)
    end
})

function lib.callback.await(event, playerId, ...)
    return trigger(nil, event, playerId, false, ...)
end

local function respond(success, result, ...)
    if not success then
        print(('^1SCRIPT ERROR: %s^0'):format(result or 'callback failed'))
        return false
    end
    return result, ...
end

function lib.callback.register(name, cb)
    registered[name] = true
    RegisterNetEvent(cbEvent:format(name), function(resource, key, ...)
        TriggerClientEvent(cbEvent:format(resource), source, key, respond(pcall(cb, source, ...)))
    end)
end

return lib.callback
