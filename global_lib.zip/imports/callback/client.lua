local pending = {}
local timers = {}
local cbEvent = '__global_cb_%s'
local timeoutMs = GetConvarInt('global:callbackTimeout', 300000)

RegisterNetEvent(cbEvent:format(cache.resource), function(key, ...)
    if source == '' then return end
    local cb = pending[key]
    if not cb then return end
    pending[key] = nil
    cb(...)
end)

local function allowed(event, delay)
    if delay and type(delay) == 'number' and delay > 0 then
        local now = GetGameTimer()
        if (timers[event] or 0) > now then return false end
        timers[event] = now + delay
    end
    return true
end

local function trigger(_, event, delay, cb, ...)
    if not allowed(event, delay) then return end

    local key
    repeat
        key = ('%s:%s'):format(event, math.random(0, 100000))
    until not pending[key]

    TriggerServerEvent(cbEvent:format(event), cache.resource, key, ...)

    local awaiter = not cb and promise.new()

    pending[key] = function(response, ...)
        if response == 'cb_invalid' then
            local message = ("callback '%s' does not exist"):format(event)
            if awaiter then return awaiter:reject(message) end
            return error(message)
        end

        local packed = { response, ... }
        if awaiter then return awaiter:resolve(packed) end
        if cb then cb(table.unpack(packed)) end
    end

    if awaiter then
        SetTimeout(timeoutMs, function()
            if pending[key] then
                pending[key] = nil
                awaiter:reject(("callback '%s' timed out"):format(event))
            end
        end)
        return table.unpack(Citizen.Await(awaiter))
    end
end

lib.callback = setmetatable({}, {
    __call = function(_, event, delay, cb, ...)
        return trigger(_, event, delay, cb, ...)
    end
})

function lib.callback.await(event, delay, ...)
    return trigger(nil, event, delay, false, ...)
end

local function respond(success, result, ...)
    if not success then
        print(('^1SCRIPT ERROR: %s^0'):format(result or 'callback failed'))
        return false
    end
    return result, ...
end

function lib.callback.register(name, cb)
    RegisterNetEvent(cbEvent:format(name), function(resource, key, ...)
        if source == '' then return end
        TriggerServerEvent(cbEvent:format(resource), key, respond(pcall(cb, ...)))
    end)
end

return lib.callback
