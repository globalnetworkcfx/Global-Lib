---@meta

if not _VERSION:find('5.4') then
    error('Lua 5.4 must be enabled in the resource manifest!', 2)
end

local resourceName = GetCurrentResourceName()
local global_lib = 'global_lib'

if resourceName == global_lib then return end

if lib and lib.name == global_lib then
    error(("Cannot load global_lib more than once.\n\tRemove any duplicate entries from '@%s/fxmanifest.lua'"):format(resourceName))
end

if GetResourceState(global_lib) ~= 'started' then
    error('^1global_lib must be started before this resource.^0', 0)
end

local glExport = exports[global_lib]
local status = glExport.hasLoaded()

if status ~= true then error(status, 2) end

msgpack.setoption('ignore_invalid', true)

local LoadResourceFile = LoadResourceFile
local context = IsDuplicityVersion() and 'server' or 'client'

function noop() end

if not string.strtrim then
    function string.strtrim(value)
        return (tostring(value):gsub('^%s*(.-)%s*$', '%1'))
    end
end

if not string.strjoin then
    function string.strjoin(sep, ...)
        return table.concat({ ... }, sep)
    end
end

if not table.contains then
    function table.contains(tbl, value)
        if type(tbl) ~= 'table' then return false end

        if type(value) ~= 'table' then
            for _, v in pairs(tbl) do
                if v == value then return true end
            end
            return false
        end

        for _, v in pairs(value) do
            local found = false
            for _, entry in pairs(tbl) do
                if entry == v then
                    found = true
                    break
                end
            end
            if not found then return false end
        end

        return true
    end
end

if not table.matches then
    function table.matches(a, b)
        if a == b then return true end
        if type(a) ~= 'table' or type(b) ~= 'table' then return false end

        for k, v in pairs(a) do
            if type(v) == 'table' then
                if not table.matches(v, b[k]) then return false end
            elseif b[k] ~= v then
                return false
            end
        end

        for k, v in pairs(b) do
            if a[k] == nil then return false end
            if type(v) == 'table' and not table.matches(a[k], v) then return false end
        end

        return true
    end
end

local moduleAliases = {
    getVehicleProperties = 'vehicle',
    setVehicleProperties = 'vehicle',
    getNearbyPlayers = 'getClosestVehicle',
    getClosestPlayer = 'getClosestVehicle',
}

local function loadModule(self, module)
    module = moduleAliases[module] or module
    local dir = ('imports/%s'):format(module)
    local chunk = LoadResourceFile(global_lib, ('%s/%s.lua'):format(dir, context))
    local shared = LoadResourceFile(global_lib, ('%s/shared.lua'):format(dir))

    if shared then
        chunk = (chunk and ('%s\n%s'):format(shared, chunk)) or shared
    end

    if not chunk then return end

    local fn, err = load(chunk, ('@@global_lib/imports/%s/%s.lua'):format(module, context))

    if not fn or err then
        return error(('\n^1Error importing module (%s): %s^0'):format(dir, err), 3)
    end

    local result = fn()
    self[module] = result or noop
    return self[module]
end

local function callExport(index, ...)
    local method = glExport[index]
    if not method then
        return error(("global_lib has no module or export '%s'"):format(index), 2)
    end
    return method(nil, ...)
end

local function call(self, index, ...)
    local module = rawget(self, index)

    if not module then
        self[index] = noop
        module = loadModule(self, index)

        if not module then
            local function method(...)
                return callExport(index, ...)
            end

            if not ... then
                self[index] = method
            end

            return method
        end

        self[index] = module
    end

    return module
end

local lib = setmetatable({
    name = global_lib,
    context = context,
}, {
    __index = call,
    __call = call,
})

local intervals = {}

function SetInterval(callback, interval, ...)
    interval = interval or 0

    if type(interval) ~= 'number' then
        return error(('Interval must be a number. Received %s'):format(json.encode(interval)))
    end

    local cbType = type(callback)

    if cbType == 'number' and intervals[callback] then
        intervals[callback] = interval or 0
        return
    end

    if cbType ~= 'function' then
        return error(('Callback must be a function. Received %s'):format(cbType))
    end

    local args, id = { ... }

    Citizen.CreateThreadNow(function(ref)
        id = ref
        intervals[id] = interval or 0
        repeat
            interval = intervals[id]
            Wait(interval)
            if interval < 0 then break end
            callback(table.unpack(args))
        until false
        intervals[id] = nil
    end)

    return id
end

function ClearInterval(id)
    if type(id) ~= 'number' then
        return error(('Interval id must be a number. Received %s'):format(json.encode(id)))
    end

    if not intervals[id] then
        return error(('No interval exists with id %s'):format(id))
    end

    intervals[id] = -1
end

local cacheEvents = {}

local function emitCache(key, value)
    local oldValue = rawget(cache, key)
    if oldValue == value then return end

    rawset(cache, key, value)

    local events = cacheEvents[key]
    if not events then return end

    for i = 1, #events do
        Citizen.CreateThreadNow(function()
            events[i](value, oldValue)
        end)
    end
end

local cache = setmetatable({ game = GetGameName(), resource = resourceName }, {
    __index = function(self, key)
        cacheEvents[key] = cacheEvents[key] or {}
        return rawset(self, key, false)[key]
    end,

    __call = function(self, key, func, timeout)
        local value = rawget(self, key)

        if value == nil then
            value = func()
            rawset(self, key, value)
            if timeout then SetTimeout(timeout, function() self[key] = nil end) end
        end

        return value
    end,
})

function lib.onCache(key, cb)
    cacheEvents[key] = cacheEvents[key] or {}
    cacheEvents[key][#cacheEvents[key] + 1] = cb
end

if context == 'client' then
    cache.playerId = PlayerId()
    cache.serverId = GetPlayerServerId(cache.playerId)

    CreateThread(function()
        while true do
            local ped = PlayerPedId()
            emitCache('ped', ped)

            local vehicle = GetVehiclePedIsIn(ped, false)
            vehicle = vehicle ~= 0 and vehicle or false
            emitCache('vehicle', vehicle)

            local seat = false
            if vehicle then
                for i = -1, 15 do
                    if GetPedInVehicleSeat(vehicle, i) == ped then
                        seat = i
                        break
                    end
                end
            end

            emitCache('seat', seat)
            Wait(200)
        end
    end)
else
    function GetActivePlayers()
        local playerNum = GetNumPlayerIndices()
        local players = table.create and table.create(playerNum, 0) or {}

        for i = 1, playerNum do
            players[i] = tonumber(GetPlayerFromIndex(i - 1))
        end

        return players
    end
end

function lib.checkDependency(resource, minimum)
    local state = GetResourceState(resource)
    if state ~= 'started' and state ~= 'starting' then
        return false, ("resource '%s' is not started"):format(resource)
    end

    if not minimum then return true end

    local current = GetResourceMetadata(resource, 'version', 0)
    if not current then return true end

    local function parts(value)
        local major, minor, patch = tostring(value):match('(%d+)%.(%d+)%.(%d+)')
        return tonumber(major) or 0, tonumber(minor) or 0, tonumber(patch) or 0
    end

    local c1, c2, c3 = parts(current)
    local m1, m2, m3 = parts(minimum)

    if c1 > m1 or (c1 == m1 and (c2 > m2 or (c2 == m2 and c3 >= m3))) then
        return true
    end

    return false, ("resource '%s' requires version %s (current %s)"):format(resource, minimum, current)
end

_ENV.lib = lib
_ENV.cache = cache

local notifyEvent = ('global_lib:notify:%s'):format(cache.resource)

if context == 'client' then
    RegisterNetEvent(notifyEvent, function(data)
        if locale and type(locale) == 'function' then
            if data.title then data.title = locale(data.title) or data.title end
            if data.description then data.description = locale(data.description) or data.description end
        end

        return glExport:notify(data)
    end)
else
    function lib.notify(playerId, data)
        TriggerClientEvent(notifyEvent, playerId, data)
    end
end

local function preload(metadataKey)
    for i = 1, GetNumResourceMetadata(cache.resource, metadataKey) do
        local name = GetResourceMetadata(cache.resource, metadataKey, i - 1)

        if name and not rawget(lib, name) then
            local module = loadModule(lib, name)
            if type(module) == 'function' then pcall(module) end
        end
    end
end

preload('global_lib')
preload('ox_libs')

_ENV.require = lib.require
