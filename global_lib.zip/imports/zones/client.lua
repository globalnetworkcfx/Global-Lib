lib.zones = {}

local zones = {}
local nextId = 0

local function rotate(dx, dy, heading)
    local rad = math.rad(heading or 0.0)
    local cosH, sinH = math.cos(rad), math.sin(rad)
    return dx * cosH + dy * sinH, -dx * sinH + dy * cosH
end

local function contains(self, coords)
    coords = coords or GetEntityCoords(cache.ped or PlayerPedId())
    local center = self.coords
    local size = self.size or vec3(2.0, 2.0, 2.0)
    local dx, dy = coords.x - center.x, coords.y - center.y
    local rx, ry = rotate(dx, dy, -(self.rotation or 0.0))
    local halfX = (size.x or size[1] or 2.0) / 2
    local halfY = (size.y or size[2] or 2.0) / 2
    local halfZ = (size.z or size[3] or 2.0) / 2
    return math.abs(rx) <= halfX and math.abs(ry) <= halfY and math.abs(coords.z - center.z) <= halfZ
end

local function create(data)
    nextId += 1
    data.id = nextId
    data.contains = contains
    data.remove = function(self)
        zones[self.id] = nil
    end
    zones[data.id] = data
    return data
end

function lib.zones.box(data)
    return create(data)
end

function lib.zones.sphere(data)
    data.size = vec3((data.radius or 2.0) * 2, (data.radius or 2.0) * 2, (data.radius or 2.0) * 2)
    return create(data)
end

CreateThread(function()
    while true do
        local coords = GetEntityCoords(cache.ped or PlayerPedId())
        local sleep = 400

        for _, zone in pairs(zones) do
            local inside = zone:contains(coords)
            if inside then
                sleep = 0
                if not zone.insideZone then
                    zone.insideZone = true
                    if zone.onEnter then zone:onEnter() end
                end
                if zone.inside then zone:inside() end
            elseif zone.insideZone then
                zone.insideZone = nil
                if zone.onExit then zone:onExit() end
            end
        end

        Wait(sleep)
    end
end)

return lib.zones
