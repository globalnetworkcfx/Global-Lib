local textOpen = false

local function notify(data)
    if type(data) == 'string' then
        data = { description = data }
    end
    if type(data) ~= 'table' then return end

    SendNUIMessage({
        action = 'notify',
        data = {
            title = data.title,
            description = data.description or data.text or '',
            type = data.type or 'inform',
            duration = data.duration or 4000,
            id = data.id,
        },
    })
end

exports('notify', notify)
exports('defaultNotify', notify)

RegisterNetEvent('global_lib:notify', function(data)
    notify(data)
end)

RegisterNetEvent('global_lib:defaultNotify', function(data)
    notify(data)
end)

local function showTextUI(text, options)
    textOpen = true
    SendNUIMessage({
        action = 'textui',
        data = {
            text = text,
            position = options and options.position or 'left-center',
        },
    })
end

local function hideTextUI()
    textOpen = false
    SendNUIMessage({ action = 'textui:hide' })
end

exports('showTextUI', showTextUI)
exports('hideTextUI', hideTextUI)
exports('isTextUIOpen', function()
    return textOpen
end)

exports('setClipboard', function(value)
    SendNUIMessage({ action = 'clipboard', data = tostring(value or '') })
end)

exports('alertDialog', function(data)
    notify({
        title = data and data.header or 'Aviso',
        description = data and (data.content or data.description) or '',
        type = 'inform',
        duration = 4000,
    })
    return 'confirm'
end)

exports('closeAlertDialog', function() end)
